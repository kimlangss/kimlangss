from PIL import Image, ImageDraw, ImageFont
def Image1(text,id):
    img  = Image.open('test.jpg')
    d = ImageDraw.Draw(img)
    fnt = ImageFont.truetype("Updock-Regular.ttf",32)
    d.text((50,200),text,font=fnt,fill=(0,0,0))
    url1 = "img_new" + "/%s.jpg" %(id)
    img.save(url1)
    return url1

