from hashlib import md5
from fake_useragent import UserAgent
import re
import text_to_image
def fake_useagen():
    regenx = re.compile(r'Mozilla/5.0 (.*?) AppleWebKit')

    ua = UserAgent()
    ua = ua['google chrome']

    kq = regenx.search(ua)
    ua = str(ua).replace(kq.group(1),'(Windows NT 10.0)')
    return ua

