import time
import requests

def taotukhoa():
    with open("tu_khoa.txt","r",encoding="utf-8") as file:   #lay tu khoa tu file
        tu_khoas = file.read()
    with open("tu_them.txt","r",encoding="utf-8") as file:  #lay tu them tu file
        tu_thems = file.read()
    tu_khoas = tu_khoas.split(",")  #tach chuoi lay tu
    tu_thems = tu_thems.split(",")  #tach chuoi lay tu
    tu_khoa_1 = []
    for tu_khoa in tu_khoas:
        for tu_them in tu_thems:
            tu_khoa_1.append(tu_khoa+"+"+tu_them) #lay ra tu khoa -> từ khoá để crawl
            tu_khoa_1.append(tu_them+"+"+tu_khoa)
        for tu_them1 in tu_thems:
            for tu_them2 in tu_thems:
                tu_khoa_1.append(tu_khoa+"+"+tu_them1+tu_them2)
                tu_khoa_1.append(tu_them1+tu_them2+"+"+tu_khoa)
    print('Cao xong tu khoa roi')
   
    return tu_khoa_1
#lay ra tu khoa
def layratukhoa():
    url = 'http://suggestqueries.google.com/complete/search?output=chrome&client=chrome&ie=UTF-8&oe=UTF-8&gl=vi&hl=vi&q='
 
    tu_khoa_1 = taotukhoa()
    a = len(tu_khoa_1)
    
    i = 0
    for item in tu_khoa_1: #lay ra tu khoa de crawl
        try:
            r = requests.get(url+item)

            chuoi_tu_khoa_crawl = str(r.json()[1]).replace("'","").strip('[]').split(",") #lay ra chuỗi từ khoá hoàn chỉnh
           
            with open("tu_khoa_crawl.txt","a+",encoding="utf-8") as file: #ghi file
                for item in chuoi_tu_khoa_crawl:
                    if item.strip(" ") != "":
                        file.writelines(str(item).strip(" ")+"\n")
            i+= 1  
            print('%d/%d' %(i,a))
            time.sleep(1)
        except:
            continue

    print('Cao xong roi')



layratukhoa()