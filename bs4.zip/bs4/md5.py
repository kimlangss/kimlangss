
import re

def bokt(string):

    new_string = re.sub(r"[^a-zA-Z0-9 -]","",string)
    return new_string


