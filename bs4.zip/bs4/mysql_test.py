import kdau
import mysql.connector
import hashlib
def insert_data(Name,title,description,keywords,detail,image,post,search):
    mydb = mysql.connector.connect(
        host = "localhost",
        user = "kimlangss",
        password="maiyeuem12",
        database = "autoweb2"

    )
  
    Name = str(Name)
    title= str(title)
  
    keywords = str(keywords)
    description = str(description)
    image= str(image)
    post = str(post)
    search = str(search)
    mycursor = mydb.cursor()
    sql = """INSERT INTO content2(
    Name, MetaTitle,Image,MetaKeywords,MetaDescriptions,Detail,post,search)
    VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"""
    val =(Name,title,image,keywords,description,detail,post,search)
    
    mycursor.execute(sql,val)

    mydb.commit()


def selectID():
    mydb = mysql.connector.connect(
        host = "localhost",
        user = "kimlangss",
        password="maiyeuem12",
        database = "autoweb2"
    )
    mycursor = mydb.cursor()
    sql = "SELECT MAX(ID)  FROM  content"
    mycursor.execute(sql)
   
    for x in mycursor:
        id = x[0]
    if str(id).isnumeric() == False:
        id = 0
    return id
def insert_data2(ID,Name,img):
    mydb = mysql.connector.connect(
        host = "localhost",
        user = "kimlangss",
        password="maiyeuem12",
        database = "autoweb2"

    )
    ID = str(ID)
    Name = str(Name)
    title= kdau.convert(Name)
    description = 'Top tim kiem %s best 2022' %(Name)
    keywords = '%s,%s' %(Name,description)
    
    img = str(img)
  
    mycursor = mydb.cursor()
    sql = """INSERT INTO content(ID,
    Name, MetaTitle,Image,MetaDescriptions,MetaKeywords)
    VALUES (%s,%s,%s,%s,%s,%s)"""
    val =(ID,Name,title,img,description,keywords)
    
    mycursor.execute(sql,val)

    mydb.commit()



