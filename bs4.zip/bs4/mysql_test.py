import kdau
import mysql.connector
import hashlib
def insert_data(Name,title,description,keywords,detail,image):
    mydb = mysql.connector.connect(
        host = "localhost",
        user = "kimlangss",
        password="maiyeuem12",
        database = "autoweb3"

    )
  
    Name = str(Name)
    title= hashlib.md5(str(title).encode('utf-8')).hexdigest()
  
    keywords = str(keywords)
    description = str(description)
    image= str(image)
    mycursor = mydb.cursor()
    sql = """INSERT INTO content2(
    Name, MetaTitle,Image,MetaKeywords,MetaDescriptions,Detail)
    VALUES (%s,%s,%s,%s,%s,%s)"""
    val =(Name,title,image,keywords,description,detail)
    
    mycursor.execute(sql,val)

    mydb.commit()



def insert_data2(Name,title,description,keywords,detail,img):
    mydb = mysql.connector.connect(
        host = "localhost",
        user = "kimlangss",
        password="maiyeuem12",
        database = "autoweb3"

    )
    Name = str(Name)
    title= str(title)
    description = str(Name)
    keywords = str(keywords)
    description = str(description)
    img = str(img)
  
    mycursor = mydb.cursor()
    sql = """INSERT INTO content(
    Name, MetaTitle,Image,MetaDescriptions,MetaKeywords,Detail)
    VALUES (%s,%s,%s,%s,%s,%s)"""
    val =(Name,title,img,description,keywords,detail)
    
    mycursor.execute(sql,val)

    mydb.commit()



