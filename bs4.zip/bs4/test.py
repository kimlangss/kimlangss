
import md5
import random
import requests
from bs4 import BeautifulSoup
import kdau
import mysql_test
import concurrent.futures
import math
import fake
import text_to_image
import hashlib


def lay_crawl_key():
    with open("tu_khoa_crawl.txt","r",encoding="utf-8") as file:   #lay tu khoa tu file
        tu_khoa = file.read()
    
    tu_khoa = tu_khoa.split("\n")
    return tu_khoa



def link_content():
    tukhoa = lay_crawl_key()
    soluong = 10
    solan = math.ceil(len(tukhoa)/soluong)
    for j in range(0,solan):
        if j== solan-1:
            soluong = len(tukhoa)

        with  concurrent.futures.ThreadPoolExecutor(max_workers=soluong) as executor:
           result = [executor.submit(crawl_post,tukhoa[i]) for i in range(soluong)]
        del tukhoa[0:soluong]
        
        print('%d/%d' %(j+1,solan))

def crawl_data_detail(url):
  
    headers = {'User-Agent': fake.fake_useagen()}
    r = requests.get(url,headers=headers,timeout=(10,5))
    html = BeautifulSoup(r.text,"html.parser")
    Name = (html.title).string
    title = kdau.convert(Name.replace('-',''))
    title = md5.bokt(title)
    title = title.strip()


   
    try:
        description = html.find("meta",{"name":"description"})['content']
    except:
        description = Name
    try:
        keywords = html.find("meta",{"name":"keywords"})['content']
    except:
        keywords = Name
    try:
        image = html.find("meta",{"property":"og:image"})['content']
    except:
        image = 'https://source.unsplash.com/random'

    detail ="<strong>Chu y :</strong>"
    detail += "<p>Note :Bức ảnh bên trên thể hiện rất rõ ràng về chủ đề " +(Name.string)+ " , nội dung bài viết vẫn đang tiếp tục cập nhật</p>"
    ps = html.find_all("p")
    if(len(ps) == 0):
        detail += "<p>Bai viet dang cap nhat them, vui long quay lai sau</p>"
    else:
        for p in ps:
            detail += str(p.text)
    
    detail += " mình còn viết thêm một bài viết liên quan tới bài viết này nhằm tổng hợp các kiến thức về "+ Name.string+"  . Mời các bạn cùng thưởng thức !"
    return str(Name).strip(),title,description,keywords,str(detail),image

   

def crawl_post(item):
    url = 'https://www.bing.com/search?q='
    headers = {'User-Agent': fake.fake_useagen()}
    try:
        r = requests.get(url+item,headers=headers,timeout=(10,5))
        html = BeautifulSoup(r.text,"html.parser")
        parent_link = html.find_all(class_='b_algo')
        if(len(parent_link) > 3):
            Name_Post = "Top " +str(len( parent_link)) +" "+ item + " best 2022"
            Description_Post = "Bài viêt về định nghĩa " + item + " và "+ Name_Post
            Keywords_Post = item + " , " + Name_Post
            Title_Post = kdau.convert(item)
            Image_Post = text_to_image.Image1(Name_Post,Title_Post)
            Content_post = '<div class="postContent" style="height: auto !important;max-width: 100%;overflow: hidden;">'
            Content_post += '''<div style="height: auto !important;"><p class="intro" style="    font-size: 16px !important;    font-weight: bold;">Duới đây là các thông tin và kiến thức về kiến thức %s của TuanSoai đi tìm hiểu: </p>''' %(item)
            for i in range(len( parent_link)):  
                try:
                    Name,title,description,keywords,(detail),image=crawl_data_detail( parent_link[i].h2.a['href'])
                    mysql_test.insert_data(str(Name),title,description,keywords,str(detail),image)
                
                    Content_post += '<p><br></p>'
                    Content_post += '<h2 id="h2_%d">%d.<a href="../../post-detail/%s">%s</a></h2>' %(i,i+1,title,Name)
                    Content_post += '''<div id="content" style="display: inline-block;background: #eff5f9;border: 1px solid #9cd5f4;border-radius: 4px;/*! width: 52%; */padding: 1.5%;margin-bottom: 10px;font-size: 14px;padding: 10px 10px 10px 20px;">
            <ul id="ul_content">'''
                    Content_post += '<li> <p><strong>Người viết: </strong> %s </p></li>' %((parent_link[i].div.div.cite).string.split("/")[2])
                    Content_post += '<li> <p><strong>Ngày đăng: </strong> %d/%d/2022 </p></li>' %(random.randint(1,30),random.randint(1,4))
                    Content_post += '<li> <p><strong>Trạng thái: </strong> %d ⭐ ( %d bình chọn ) </p></li>' %(random.randint(1,10),random.randint(1,1618))
                    Content_post += '<li> <p><strong>Trạng thái max: </strong> %d ⭐ </p></li>' %(random.randint(1,10))
                    Content_post += '<li> <p><strong>Trạng thái min: </strong> %d ⭐ </p></li>' %(random.randint(1,10))
                    Content_post +=  '<li> <p><strong>Tóm tắt: </strong> <span class="content">%s</span> </p></li>' %(Name)
                    Content_post += '<li> <p><strong>Ứng với tìm kiếm: </strong><span class="content">%s </span> </p> </li>' %(parent_link[i].div.p)
                    Content_post += '<p style="text-align: center;"><a href="../../post-detail/%s" style="background-color: #009dea;color: white;padding: 10px 15px;text-decoration: none;text-transform: uppercase;border-radius: 5px;text-align: center;margin: 0;"> Vào luôn </a></p>' %(title)
                    Content_post += '</ul></div>'
                    Content_post += '<p><br></p>'
                except:
                    
                    continue
            Content_post += '</div>'
            Content_post += '</div>'
            mysql_test.insert_data2(Name_Post,Title_Post,Description_Post,Keywords_Post,Content_post,Image_Post)
    except:
        print('Loi roi')





link_content()









