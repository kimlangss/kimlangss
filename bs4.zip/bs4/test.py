
import random
import requests
from bs4 import BeautifulSoup
import kdau
import mysql_test
import threading
import math
import fake
import text_to_image
from time import sleep

global_lock = threading.Lock()

def lay_crawl_key():
    with open("tu_khoa_crawl.txt","r",encoding="utf-8") as file:   #lay tu khoa tu file
        tu_khoa = file.read()
    
    tu_khoa = tu_khoa.split("\n")
    return tu_khoa

def crawl_post(id,item):
    
    url = 'https://www.bing.com/search?q='
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/53%d.36' %random.randint(1,9)}
    try:
        r = requests.get(url+item,headers=headers,timeout=(10,10))
        html = BeautifulSoup(r.text,"html.parser")
        parent_link = html.find_all(class_='b_algo')
        if(len(parent_link) > 3):
            a = '<title id=%d>%s</title>' %(id,item)
            for item1 in parent_link:
                try:
                    a += "<a title= '%s' href='%s'>%s</a>" %(item1.h2.a.string,item1.h2.a['href'],item1.div.p)
                except:
                    continue
            while global_lock.locked():
                sleep(0.01)
                continue
            global_lock.acquire()
            with open("post.txt","a",encoding="utf-8") as file:
                file.write(a +"\n")
                file.close()
            global_lock.release()
    except:
        print("Loi roi")
def link_content():
    tukhoa = lay_crawl_key()
    
    soluong = 7
    solan = math.ceil(len(tukhoa)/soluong)
    id = mysql_test.selectID()+1
    for j in range(0,solan):
        thread_list = []
        if j== solan-1:
            soluong = len(tukhoa)

        
        for i in range(0, soluong):

         
            t = threading.Thread(target=crawl_post, args=(id+i,tukhoa[i],))
            thread_list.append(t)

        # Starts threads
        for thread in thread_list:
            thread.start()
        
        for thread in thread_list:
            thread.join()

        del tukhoa[0:soluong]
        id = id + soluong
        print('%d/%d' %(j+1,solan))

def crawl_data_detail(url):
  
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/53%d.36' %random.randint(1,9)}
    r = requests.get(url,headers=headers,timeout=(10,20))
    html = BeautifulSoup(r.text,"html.parser")
    Name = (html.title).string
    title = kdau.convert(Name.replace('-',''))
    title = title.strip()


   
    try:
        description = html.find("meta",{"name":"description"})['content']
    except:
        description = Name
    try:
        keywords = html.find("meta",{"name":"keywords"})['content']
    except:
        keywords = Name
    try:
        image = html.find("meta",{"property":"og:image"})['content']
    except:
        image = 'https://source.unsplash.com/random'
    if image == '':
        image = 'https://source.unsplash.com/random'
    detail ="<strong>Chu y :</strong>"
    detail += "<p>Note :Bức ảnh bên trên thể hiện rất rõ ràng về chủ đề " +(Name.string)+ " , nội dung bài viết vẫn đang tiếp tục cập nhật</p>"
    ps = html.find_all("p")
    if(len(ps) == 0):
        detail += "<p>Bai viet dang cap nhat them, vui long quay lai sau</p>"
    else:
        for p in ps:
            detail += str(p.text)
    
    detail += " mình còn viết thêm một bài viết liên quan tới bài viết này nhằm tổng hợp các kiến thức về "+ Name.string+"  . Mời các bạn cùng thưởng thức !"
    return str(Name).strip(),title,description,keywords,str(detail),image

   


def insert_post():
    with open("post.txt","r",encoding="utf-8") as file:
        crawl = file.read().strip("\n")
        
    
    crawl = crawl.split('\n')
    for item in crawl:
        doc = BeautifulSoup(item,"html.parser")
        a = doc.title.string
        b = doc.title['id']
        c = 'Top tìm kiếm %s best 2022' %(a)
        img = text_to_image.Image1(c,b)
        mysql_test.insert_data2(b,a,img)
def insert_post_detail(item):
    doc = BeautifulSoup(item,"html.parser")
    e = doc.find_all("a")
    b = doc.title['id']
    
    for item1 in e:
        try:
            Name,title,description,keywords,(detail),image=crawl_data_detail(item1["href"])
            while global_lock.locked():
                sleep(0.01)
                continue
            global_lock.acquire()
            mysql_test.insert_data(str(Name),title,description,keywords,str(detail),image,b,item1.p)
            global_lock.release()
        except:
            continue
           
def insert_post_detail_2():
    with open("post.txt","r",encoding="utf-8") as file:
        crawl = file.read().strip("\n")
    crawl = crawl.split('\n')
    soluong = 200
    solan = math.ceil(len(crawl)/soluong)
    for j in range(0,solan):
        thread_list = []
        if j== solan-1:
            soluong = len(crawl)

        
        for i in range(0, soluong):

            
            t = threading.Thread(target=insert_post_detail, args=(crawl[i],))
            thread_list.append(t)

        # Starts threads
        for thread in thread_list:
            thread.start()
        
        for thread in thread_list:
            thread.join()

        del crawl[0:soluong]
        print('%d/%d' %(j+1,solan))


insert_post_detail_2()













